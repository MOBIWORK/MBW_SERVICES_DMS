OPTIMAL_ROUTER = {
    "EKGIS": "https://api.ekgis.vn/navigation/vrp",
    "GOOGLE": ""
}