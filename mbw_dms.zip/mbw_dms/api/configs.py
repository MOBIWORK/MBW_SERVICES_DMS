customer_type = {
    "Company": "Company",
    "Individual": "Individual",
    "Proprietorship": "Proprietorship",
    "Partnership": "Partnership"
}
status_type = {
    "Chưa phản hồi": "Chưa phản hồi",
    "Đã phản hồi": "Đã phản hồi",
    "Hoạt động": "Hoạt động",
    "Không hoạt động": "Không hoạt động"
}

discount_type = {
    "Grand Total": "Grand Total",
    "Net Total": "Net Total"
}

status_order = {
    "Draft" : "Chờ duyệt",
    "To Deliver and Bill": "Chờ vận chuyển và chờ thanh toán",
    "To Bill": "Chờ thanh toán",
    "To Deliver": "Chờ vận chuyển",
    "Completed": "Hoàn thành",
    "Cancelled": "Đã hủy",
    "All": ""
}

day_name_translation = {
    "Monday": "Thứ Hai",
    "Tuesday": "Thứ Ba",
    "Wednesday": "Thứ Tư",
    "Thursday": "Thứ Năm",
    "Friday": "Thứ Sáu",
    "Saturday": "Thứ Bảy",
    "Sunday": "Chủ Nhật"
}