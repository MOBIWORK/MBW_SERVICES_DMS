API_URL = "https://api.ekgis.vn/v1/checkin"
API_URL_TRACKING = "https://api.ekgis.vn/tracking"