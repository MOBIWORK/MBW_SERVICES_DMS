template_header = {
    "Report KPI" : "mbw_dms.mbw_dms.doctype.dms_kpi.dms_kpi.report",
    "Report Inventory": "mbw_dms.mbw_dms.doctype.dms_inventory.dms_inventory.handle_filter_find_v2",
    "Report Checkin": "mbw_dms.mbw_dms.doctype.dms_checkin.dms_checkin.get_report",
    "Report Sell": "mbw_dms.api.report.so_report.handle_si_report",
    "Report Order": "mbw_dms.api.report.so_report.handle_so_report",
    "Report Customer": "mbw_dms.api.report.customer_report.handle_customer_report",
    "Report Customer Checkin": "mbw_dms.api.report.first_checkin_rp.handle_first_checkin_report"
}