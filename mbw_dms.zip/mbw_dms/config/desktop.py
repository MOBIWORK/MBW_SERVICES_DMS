from frappe import _

def get_data():
	return [
		{
			"module_name": "MBW DMS",
			"type": "module",
			"label": _("MBW DMS")
		}
	]
