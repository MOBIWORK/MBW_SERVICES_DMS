import{bq as t}from"./index-apzEk_Jm.js";import{D as o}from"./index-pVnGm3q-.js";const i=t(o)`
    background: #F5F7FA !important;
`;export{i as D};
