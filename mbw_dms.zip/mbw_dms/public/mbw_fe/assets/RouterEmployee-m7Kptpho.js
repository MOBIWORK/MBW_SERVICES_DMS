import{L as e,ad as r}from"./index-apzEk_Jm.js";function a(){return e.jsxs(e.Fragment,{children:[e.jsx(r,{children:e.jsx("script",{children:` var map = new maplibregl.Map({
      "container": 'map',
      "center": [105, 17],
      "zoom": 4
        });
      var mapOSMBright = new ekmapplf.VectorBaseMap(
        'OSM:Bright',
        'wtpM0U1ZmE2s87LEZNSHf63Osc1a2sboaozCQNsy'
      ).addTo(map);`})}),e.jsx("div",{id:"map",className:"h-[400px]"})]})}function s(){return e.jsxs(e.Fragment,{children:[e.jsx(r,{children:e.jsx("title",{children:" RouterControll"})}),e.jsx(a,{})]})}export{s as default};
