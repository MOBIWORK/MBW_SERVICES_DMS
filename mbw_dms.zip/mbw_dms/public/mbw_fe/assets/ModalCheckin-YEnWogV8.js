import{bq as a,ac as o}from"./index-apzEk_Jm.js";const t=a(o)`
  .ant-modal-content{
    padding: 0px;
    border-radius: 12px;
    overflow: hidden;
  }
`;export{t as M};
