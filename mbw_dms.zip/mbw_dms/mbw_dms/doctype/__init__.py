

class WrapperDocument():
    def __init__(self,doctype):
        self.doctype = doctype
    
    