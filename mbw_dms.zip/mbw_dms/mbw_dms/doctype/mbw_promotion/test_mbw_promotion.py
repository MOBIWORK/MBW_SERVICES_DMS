# Copyright (c) 2024, MBW and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestMBWPromotion(FrappeTestCase):
	pass
